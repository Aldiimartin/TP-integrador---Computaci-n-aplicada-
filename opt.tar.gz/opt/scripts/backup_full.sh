#!/bin/bash 

if [ "$1" = "-help" ]; then
	echo "uso: backup_full.sh ORIGEN DESTINO" 
	echo "Ejemplo: backup_full.sh /var/log /backup_dir" 
	exit 0
fi 

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

if [ $# -ne 2 ]; then 
	echo "Error: debe indicar origen y destino" 
	echo "Use -help para ver la ayuda." 
	exit 
fi 

if [ ! -d "$ORIGEN" ]; then
	echo "Error: el origen no existe o no es un directorio"
	exit 1
fi 

if [ ! -d "$DESTINO" ]; then 
	echo "Error: el destino no existe o no es un directorio"
	exit 1
fi 

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN" 

echo "Backup generado en: $DESTINO/$ARCHIVO"
