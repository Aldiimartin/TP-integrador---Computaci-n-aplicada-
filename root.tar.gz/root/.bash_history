history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
nano /etc/hostname
cat /etc/hostname
echo TPServer > /etc/hostname
cat /etc/hostname
reboot
lbs_release -a
lsb_release -a
apt update
apt upgrade
apt autoremove
ip addr
cat /etc/network/interfaces
ping -c 4 8.8.8.8 
ping -c 4 deb.debian.org
apt update 
cat /etc/apt/sources.list
cp /etc/apt/sources.list /etc/apt/sources.list.bak
cat > /etc/apt/sources.list
cp /etc/apt/sources.list.bak /etc/apt/sources.list
cat /etc/apt/sources.list 
vi --version
vi /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt upgrade
apt autoremove
apt clean
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
poweroff
apt update
upt upgrade
apt upgrade
lsb_release -a
uname -r
hostname
poweroff
cat /etc/apt/sources.list
vi /etc/apt/sources.list
ls /root
tar -tzf / root/material_Adicional_TPMCA.tar.gz
poweroff
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /ROOT
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls -l /root/Material_Adicional_TPVMCA
dpkg -l | grep openssh
apt install openssh-server
systemctl status ssh
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chomod 700 /root/.ssh
chmod 700 /root/.ssh 
chmod 600 /root/.ssh/authorized_keys
ls -l /root/.ssh
grep -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
grep -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
grep -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
systemctl status ssh
hostname
dpkg -l | grep apache2
php -v
php -v
poweroff
ip addr show enp0s3
ip route
ip addr show enp0s3
ping -c 4 8.8.8.8
ping -c 4 debian.org
ip route
cat /etc/network/interfaces
ip route add default via 192.168.1.1 dev enp0s3
ip route
ping -c 4 8.8.8.8
ip addr show enp0s3
ip route
shutdown -h now
fdisk -l
porweroff
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
blkid /dev/sdc1  /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1  /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp -r /var/www/html/* /www_dir/
ls -l /www_dir
grep -n "DocumentRoot" /etc/apache2/sites_available/000-default.conf
grep -n "DocumentRoot" /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/sites-available/000-default.conf
grep -n "DocumentRoot" /etc/apache22/sites-available/000-default.conf
grep -n "DocumentRoot" /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
systemctl status apache2
ls -ld /www_dir
ls -l /www_dir
cp /cat/apache2/sites-available/000-default.conf
cat /etc/apache2/sites-available/000-default.conf
vi /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
blkid /dev/sdc1 /dev/sdc2
vi /etc/fstab
mount -a
nl -ba /etc/fstab | tail -n 10
vi /etc/fstab
mount -a
vi /etc/fstab
mount -a
df -h
mkdir -p /opt/particion
cp /proc/partitions /opt/particion/
ls -l /opt/particion 
cat /opt/particion/partitions
lsblk
df -h
ls /etc/fstab
cat /etc/fstab
cat /opt/particion/partitions
reboot
